
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include"10 functions.h"
#include"header.h"
#include<filesystem>
using namespace std;

bool fileExists (const string& this_file) {
    ifstream file(this_file);
    return file.good();
}

bool endsWith(const std::string& str, const std::string& suffix) {
    if (str.length() >= suffix.length()) {
        return (0 == str.compare(str.length() - suffix.length(), suffix.length(), suffix));
    }
    return false;
}


int main(int argc, char* argv[]) {
    Processing top_layer;
    string checkIfTga = ".tga";
    vector<string> args;

    for(int i = 0; i < argc; i++) {
        args.push_back((string)(argv[i]));
    }

    //cout<< argc << endl;
    //int x = argc;
    //while (x > 0) {
    //help message
    for(int i = 0; i < args.size(); i++) {
        if (argc > 1 && args.at(1) == "--help" || argc < 2){
            cout << "Project 2: Image Processing, Fall 2024" << endl;
            cout << endl;
            cout << "Usage:" << endl;
            cout << "\t./project2.out [output] [firstImage] [method] [...]" << endl;
            return 0;
        } else if (!endsWith(args.at(1), checkIfTga)) {
            //checks the out file name
            cout << "Invalid file name." << endl;
            return 0;
        }
        else if(argc > 3 && !(args.at(3) == "multiply" || args.at(3) == "subtract" || args.at(3) == "screen" ||
            args.at(3) == "overlay" || args.at(3) == "addred" || args.at(3) == "addgreen" ||
            args.at(3) == "addblue" || args.at(3) == "scalered" || args.at(3) == "scalegreen" ||
            args.at(3) == "scaleblue" || args.at(3) == "flip" || args.at(3) == "onlyred" ||
            args.at(3) == "onlygreen" || args.at(3) == "onlyblue" || args.at(3) == "combine")) {
            //checks to see if the method name is valid
            cout << "Invalid method name." << endl;
            return 0;
        } else if(argc > 4 && ((args.at(3) == "multiply" || args.at(3) == "subtract" || args.at(3) == "screen" ||
            args.at(3) == "overlay")  && (!endsWith(args.at(4), checkIfTga)))) {
            //checks to see if the file after the given methods is a valid tga name
            cout << "Invalid argument, invalid file name." << endl;
            return 0;

        } else if(argc > 4 && (!fileExists(args.at(4)) && (((args.at(3) == "multiply" ||
            args.at(3) == "subtract" || args.at(3) == "screen" ||
            args.at(3) == "overlay"))))) {
            //checks to see if the file after the given methods exists
            cout << "Invalid argument, file does not exist." << endl;
            return 0;

        } /*else if(argc > 4 &&
            (fileExists(args.at(2)) && (((args.at(i) == "addred" ||
            args.at(i) == "addgreen" || args.at(i) == "addblue" ||
            args.at(i) == "scalered" || args.at(i) == "scalegreen" || args.at(i) == "scaleblue"))))) {
            const string& image2 = args.at(i+1);
            cout << i+1 << endl;
            try {
                stoi(image2);
            } catch (invalid_argument&) {
                cout << "Invalid argument, expected number." << endl;
                return 0;

            } */
                //checks to see if the integer after the given files exists


        else if(argc == i+1 && (args.at(i) == "addred" ||
            args.at(i) == "addgreen" || args.at(i) == "addblue" ||
            args.at(i) == "scalered" || args.at(i) == "scalegreen" || args.at(i) == "scaleblue")) {
            cout <<"Missing argument."<< endl;
            return 0;
        }
        else if((!fileExists(args.at(2)) || !endsWith(args.at(2), checkIfTga))) {
            cout << "File does not exist." << endl;
            return 0;
        }
        i++;
    }

    int i = 0;
    const string& image1 = args.at(2);
    top_layer = ReadHeader(image1);

    i+= 3;
    while (i < args.size()) {
        if ((fileExists(args.at(i)) && endsWith(args.at(1) ,checkIfTga)) ||
            args.at(i) == "multiply" || args.at(i) == "subtract" || args.at(i) == "screen" ||
            args.at(i) == "overlay" || args.at(i) == "addred" || args.at(i) == "addgreen" ||
            args.at(i) == "addblue" || args.at(i) == "scalered" || args.at(i) == "scalegreen" ||
            args.at(i) == "scaleblue" || args.at(i) == "flip" || args.at(i) == "onlyred" ||
            args.at(i) == "onlygreen" || args.at(i) == "onlyblue" || args.at(i) == "combine"){
            cout << "i =" << i << endl;
            const string& output = args.at(1);
            if(i >= args.size()) {
                cout << "Missing method" << endl;
                return 1;
            }
            cout << "i =" << i << endl;
            const string& method = args.at(i);

            i++;
            //i = 4

            if(method == "multiply" || method == "subtract" || method == "overlay" || method == "screen") {
                if(i >= args.size()) {
                    cout << "Missing argument." << endl;
                } else if (!fileExists(args.at(2)) || !endsWith(args.at(2), checkIfTga)) {
                    if(!endsWith(args.at(1), checkIfTga)) {
                        cout << "Invalid argument, invalid file name." << endl;
                    }
                }
                const string& image2 = args.at(i);
                cout << "Computing given method: " << method << endl;
                cout << "Between these two files: " << image1 << " and " << image2 << endl;
                Processing bottom_layer = ReadHeader(image2);

                if(method == "multiply") {
                    top_layer = multiply(top_layer, bottom_layer);
                } else if (method == "subtract") {
                    top_layer = subtract(top_layer, bottom_layer);
                } else if (method == "overlay") {
                    top_layer = overlay(top_layer, bottom_layer);
                } else if (method == "screen") {
                    top_layer = screen(top_layer, bottom_layer);
                }
                write_File(output, top_layer);
                //i++;
            } else if(method == "addred" || method == "addgreen" || method == "addblue") {
                if(i >= args.size()) {
                    cout << "No integer after add color called" << endl;
                }
                const string& image2 = args.at(i);
                int integer = stoi(image2);
                cout << "Computing given method: " << method << endl;
                cout << "Between add color and integer: " << image1 << " and " << image2 << endl;

                if(method == "addred") {
                    top_layer = addRed(top_layer, integer);
                } else if (method == "addgreen") {
                    top_layer = addGreen(top_layer, integer);
                } else if (method == "addblue") {
                    top_layer = addBlue(top_layer, integer);
                }
                write_File(output, top_layer);
                //i++;

            } else if(method == "scalered" || method == "scalegreen" || method == "scaleblue") {
                if(i >= args.size()) {
                    cout << "No integer after add color called" << endl;
                }
                const string& image2 = args.at(i);
                int integer = stoi(image2);
                cout << "Computing given method: " << method << endl;
                cout << "Between add color and integer: " << image1 << " and " << image2 << endl;

                if(method == "scalered") {
                    top_layer = scaleRed(top_layer, integer);
                } else if (method == "scalegreen") {
                    top_layer = scaleGreen(top_layer, integer);
                } else if (method == "scaleblue") {
                    top_layer = scaleBlue(top_layer, integer);
                }
                write_File(output, top_layer);
                //i++;
            } else if(method == "flip" || method == "onlyred" || method == "onlygreen" || method == "onlyblue") {
                cout << "Computing given method: " << method << endl;
                cout << "On given file: " << image1 << endl;

                if(method == "flip") {
                    top_layer = rotate(top_layer);
                } else if (method == "onlyred") {
                    top_layer = separate_channels(top_layer, 3);
                } else if (method == "onlygreen") {
                    top_layer = separate_channels(top_layer, 2);
                } else if (method == "onlyblue") {
                    top_layer = separate_channels(top_layer, 1);
                }
                write_File(output, top_layer);
                //i++;
            } else if (method == "combine") {
                if(i >= args.size() || !endsWith(args.at(i), checkIfTga) || !fileExists(args.at(i))) {
                    cout << "First argument doesnt exist" << endl;
                    if(i+1 >= args.size() || !endsWith(args.at(i+1), checkIfTga) || !fileExists(args.at(i+1))) {
                        cout << "No second argument after method or file doesnt exist" << endl;
                    }
                }
                const string& image2 = args.at(i);
                const string& image3 = args.at(i+1);
                cout << "Computing given method: " << method << endl;
                cout << "Between these three files: " << image1 << " and " << image2 << image3 << endl;
                Processing middle_layer = ReadHeader(image2);
                Processing bottom_layer = ReadHeader(image3);


                if(method == "combine") {
                    top_layer = combine_channels(top_layer, middle_layer, bottom_layer);
                }
                write_File(output, top_layer);
                i++;

            }
            else {
                cout << "Invalid method name." << endl;
            }
        } else if(i >= args.size()) {
            break;
        } else{
            cout << "Invalid file name." << endl;
            break;
        }
        i++;
    }
    return 0;
}















/*
    //Multiply
    Processing top_layer1;
    top_layer1 = ReadHeader("input/layer1.tga");
    Processing bottom_layer1 = ReadHeader("input/pattern1.tga");
    Processing write_this1 = multiply(top_layer1, bottom_layer1);
    write_File("output/part1.tga", write_this1);

    //Subract
    Processing top_layer2;
    top_layer2 = ReadHeader("input/car.tga");
    Processing bottom_layer2 = ReadHeader("input/layer2.tga");
    Processing write_this2 = subtract(top_layer2, bottom_layer2);
    write_File("output/part2.tga", write_this2);

    //Screen
    Processing top_layer3 = ReadHeader("input/layer1.tga");
    Processing bottom_layer3 = ReadHeader("input/pattern2.tga");
    Processing write_this3 = multiply(top_layer3, bottom_layer3);
    Processing new_bottom_layer3 = ReadHeader("input/text.tga");
    Processing new_top_layer3 = write_this3;
    Processing new_write_this3 = screen(new_top_layer3, new_bottom_layer3);
    write_File("output/part3.tga", new_write_this3);

    //Multiply than Subtract
    Processing top_layer4 = ReadHeader("input/layer2.tga");
    Processing bottom_layer4 = ReadHeader("input/circles.tga");
    Processing write_this4 = multiply(top_layer4,bottom_layer4);
    Processing new_top_layer4 = write_this4;
    Processing new_bottom_layer4 = ReadHeader("input/pattern2.tga");
    Processing new_write_this4 = subtract(new_top_layer4, new_bottom_layer4);
    write_File("output/part4.tga", new_write_this4);

    //Overlay
    Processing top_layer5 = ReadHeader("input/layer1.tga");
    Processing bottom_layer5 = ReadHeader("input/pattern1.tga");
    Processing write_this5 = overlay(top_layer5, bottom_layer5);
    write_File("output/part5.tga", write_this5);

    //+200 Green
    Processing top_layer6 = ReadHeader("input/car.tga");
    Processing write_this6 = addGreen(top_layer6);
    write_File("output/part6.tga", write_this6);

    //7
    Processing top_layer7 = ReadHeader("input/car.tga");
    Processing write_this7 = scale1(top_layer7);
    write_File("output/part7.tga", write_this7);

    //8
    Processing top_layer8 = ReadHeader("input/car.tga");
    Processing write_this_blue = separate_channels(top_layer8, 1);
    Processing write_this_green = separate_channels(top_layer8, 2);
    Processing write_this_red = separate_channels(top_layer8, 3);
    write_File("output/part8_r.tga", write_this_red);
    write_File("output/part8_g.tga", write_this_green);
    write_File("output/part8_b.tga", write_this_blue);

    //9
    Processing top_layer9 = ReadHeader("input/layer_blue.tga");
    Processing middle_layer9 = ReadHeader("input/layer_green.tga");
    Processing bottom_layer9 = ReadHeader("input/layer_red.tga");
    Processing write_this9 = combine_channels(top_layer9, middle_layer9, bottom_layer9);
    write_File("output/part9.tga", write_this9);

    //10
    Processing top_layer10 = ReadHeader("input/text2.tga");
    Processing write_this10 = rotate(top_layer10);
    write_File("output/part10.tga", write_this10);
*/

